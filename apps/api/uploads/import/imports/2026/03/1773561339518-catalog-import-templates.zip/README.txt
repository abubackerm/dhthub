Catalog Import Templates
========================

This ZIP file contains CSV templates for importing large industrial catalogs (500k+ variants).

FILES
------
1. products_template.csv     - Product family definitions
2. variants_template.csv     - SKU/product variant details (required)
3. images_template.csv       - Product variant images
4. attributes_template.csv   - Attribute metadata (optional)
5. attribute-options_template.csv - Attribute enum values (optional)

USAGE
-----

1. Prepare your data:
   - Download these templates
   - Fill in your product data (variants.csv is required)
   - Optional: provide attributes.csv to define attribute metadata
   - Optional: provide attribute-options.csv for enum attributes
   - Optional: provide images.csv with image URLs (will be downloaded and stored)

2. Create a ZIP archive:
   - Name it: catalog-import.zip
   - Include your CSV files (must match template filenames exactly)
   - Required files: variants.csv
   - Optional files: products.csv, images.csv, attributes.csv, attribute-options.csv

3. Upload via API:
   - POST /v1/import/jobs
   - Content-Type: multipart/form-data
   - File field: file
   - Accepts: .zip (multi-CSV) or .csv (single file)

TEMPLATE DETAILS
---------------

products.csv
------------
Defines product families (groups of variants).
Each row is a product family.

Required columns:
- product_slug: Unique identifier (e.g., wedge-anchor)
- product_name: Display name
- category_slug: Category path (e.g., anchors, industrial.fasteners.hex-bolts)
- description: Product description

Example:
product_slug,product_name,category_slug,description
wedge-anchor,Wedge Anchor,anchors,Steel wedge anchors for concrete fastening

variants.csv
-----------
Defines individual SKUs.
Each row is a product variant.

Required columns:
- product_slug: References product_slug from products.csv
- sku: Unique SKU identifier
- price: Unit price (numeric)
- stock: Stock quantity (integer)

Dynamic columns (optional):
- All other columns are treated as attributes
- Example: diameter, length, material, finish
- System fields: product_slug, sku, price, stock

Example:
product_slug,sku,price,stock,diameter,length,material,finish
wedge-anchor,91578A103,0.71,500,1/4,1.75,Steel,Zinc

images.csv
----------
Associates images with SKUs.

Required columns:
- sku: References SKU from variants.csv
- image_url: Public URL (will be downloaded and stored in object storage)

Example:
sku,image_url
91578A103,https://cdn.example.com/images/91578A103.jpg

attributes.csv
--------------
Defines attribute metadata.
If not provided, attributes will be auto-created from variants.csv columns.

Required columns:
- attribute_slug: Unique identifier (e.g., diameter)
- name: Display name
- type: Data type (number, text, enum, boolean)
- display_order: Sort order (integer)

Example:
attribute_slug,name,type,display_order
diameter,Diameter,number,1
material,Material,enum,3

attribute-options.csv
-------------------
Defines enum values for enum-type attributes.

Required columns:
- attribute_slug: References attribute_slug from attributes.csv
- option_value: Enum value

Example:
attribute_slug,option_value
material,Steel
material,Stainless Steel
finish,Zinc

VALIDATION RULES
----------------

1. variants.csv:
   - sku must be unique
   - product_slug must exist in products.csv (if provided)
   - price and stock must be numeric

2. products.csv:
   - product_slug must be unique
   - category_slug must reference an existing category

3. images.csv:
   - sku must exist in variants.csv
   - image_url must be a valid URL

4. attributes.csv:
   - attribute_slug must be unique
   - type must be: number, text, enum, or boolean

5. attribute-options.csv:
   - attribute_slug must exist in attributes.csv

IMPORT WORKFLOW
----------------

When you upload a ZIP:

1. Extract archive
2. Validate required files (variants.csv required)
3. Create ImportJob
4. Queue worker for async processing

Worker pipeline:
Step 1 - Import products
Step 2 - Import attributes (or auto-create from variants)
Step 3 - Import variants (in batches of 500)
Step 4 - Import images (download from URLs)
Step 5 - Update search index

ERRORS
-------

Row-level errors are recorded and can be retrieved via:
GET /v1/import/jobs/:id/errors

Each error includes:
- row number
- SKU (if applicable)
- error message
- raw data from the row
- source file name

PERFORMANCE
-----------

Designed for large-scale catalogs:
- 500k products
- 1M+ variants

Optimizations:
- Stream CSV files (never load entire file into memory)
- Process variants in batches of 500
- Use database transactions
- Parallel image downloads
- Record errors without failing entire import

SUPPORT
-------

For issues or questions, contact your system administrator.
